import 'package:flutter/material.dart';
import 'core/i18n.dart';
import 'core/theme_tokens.dart';
import 'screens/home_screen.dart';

void main() => runApp(const ActiveInterruptApp());

class ActiveInterruptApp extends StatelessWidget {
  const ActiveInterruptApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
    valueListenable: appLang,
    builder: (_, __, ___) => MaterialApp(
      title: 'ActiveInterrupt',
      debugShowCheckedModeBanner: false,
      theme: Tk.book.theme(),
      darkTheme: Tk.indigo.theme(),
      themeMode: ThemeMode.system, // অটো
      home: const HomeScreen(),
    ),
  );
}
