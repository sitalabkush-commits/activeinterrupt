import 'package:flutter/material.dart';
import '../core/i18n.dart';
import '../core/theme_tokens.dart';
import '../services/ai_client.dart';
import '../services/key_store.dart';

class AiSettingsScreen extends StatefulWidget {
  const AiSettingsScreen({super.key});
  @override
  State<AiSettingsScreen> createState() => _S();
}

class _S extends State<AiSettingsScreen> {
  String provider = 'groq';
  final model = TextEditingController(), endpoint = TextEditingController(), key = TextEditingController();
  String tail = '', status = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    provider = await KeyStore.getPref('provider', 'groq');
    model.text = await KeyStore.getPref('model');
    endpoint.text = await KeyStore.getPref('endpoint');
    tail = await KeyStore.maskedTail();
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    await KeyStore.setPref('provider', provider);
    await KeyStore.setPref('model', model.text.trim());
    await KeyStore.setPref('endpoint', endpoint.text.trim());
    if (key.text.trim().isNotEmpty) await KeyStore.saveKey(key.text);
    key.clear();
    tail = await KeyStore.maskedTail();
    setState(() => status = 'সংরক্ষিত');
  }

  @override
  Widget build(BuildContext c) {
    final t = tkOf(c);
    Widget chip(String id, String label) => InkWell(
      onTap: () => setState(() => provider = id),
      child: Container(
        alignment: Alignment.center, height: 52,
        decoration: BoxDecoration(
          color: t.card, borderRadius: BorderRadius.circular(t.btnR),
          border: Border.all(color: provider == id ? t.accent2 : t.border, width: provider == id ? 2 : 1)),
        child: Text(label)),
    );
    return Scaffold(
      appBar: AppBar(title: Text(tr('ai_settings')), backgroundColor: t.bg, elevation: 0),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(tr('ai_note'), style: TextStyle(color: t.soft)),
        const SizedBox(height: 16),
        GridView.count(crossAxisCount: 2, shrinkWrap: true, childAspectRatio: 3, mainAxisSpacing: 10, crossAxisSpacing: 10,
          physics: const NeverScrollableScrollPhysics(),
          children: [chip('auto', 'Auto'), chip('groq', 'Groq'), chip('deepseek', 'DeepSeek'), chip('custom', 'কাস্টম')]),
        const SizedBox(height: 16),
        TextField(controller: model, decoration: InputDecoration(labelText: tr('model'))),
        const SizedBox(height: 12),
        TextField(controller: endpoint, decoration: InputDecoration(labelText: tr('endpoint'))),
        const SizedBox(height: 12),
        // পেস্ট সবসময় চালু
        TextField(controller: key, obscureText: true, decoration: InputDecoration(labelText: 'API key', hintText: tail)),
        const SizedBox(height: 8),
        Text(tail.isEmpty ? '' : '$tail  (সক্রিয়)', style: TextStyle(color: t.accent2)),
        Text(tr('key_note'), style: TextStyle(color: t.soft, fontSize: 13)),
        const SizedBox(height: 16),
        SizedBox(height: 52, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(t.btnR))),
          onPressed: _save, child: Text(tr('save')))),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: SizedBox(height: 48, child: OutlinedButton(
            onPressed: () async {
              setState(() => status = '...');
              final e = await AiClient.test();
              setState(() => status = e ?? 'সফল');
            }, child: Text(tr('test'))))),
          const SizedBox(width: 10),
          Expanded(child: SizedBox(height: 48, child: OutlinedButton(
            onPressed: () async { await KeyStore.deleteKey(); await _load(); setState(() => status = 'মোছা হয়েছে'); },
            child: Text(tr('del_key'))))),
        ]),
        const SizedBox(height: 12),
        Text(status, style: TextStyle(color: t.soft)),
      ]),
    );
  }
}
