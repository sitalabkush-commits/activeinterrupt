import 'package:flutter/material.dart';
import '../core/i18n.dart';
import '../core/theme_tokens.dart';
import 'ai_settings_screen.dart';
import 'overlay_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext c) {
    final t = tkOf(c);
    Widget card(Widget ch) => Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: t.card, borderRadius: BorderRadius.circular(t.cardR + 2), border: Border.all(color: t.border)),
      child: ch);
    void go(Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
    return Scaffold(
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(tr('greet'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
          IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => go(const AiSettingsScreen())),
        ]),
        const SizedBox(height: 16),
        card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr('next_q'), style: TextStyle(color: t.soft)),
          const SizedBox(height: 6),
          Text('24:10', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700, color: t.accent2)),
        ])),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: card(Text('${tr('streak')}\n12'))),
          const SizedBox(width: 12),
          Expanded(child: card(Text('${tr('level')}\n3'))),
        ]),
        const SizedBox(height: 12),
        card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr('weak')), const SizedBox(height: 8),
          LinearProgressIndicator(value: 0.62, color: t.accent, backgroundColor: t.border, minHeight: 8),
          const SizedBox(height: 8),
          Text('Gender ভুল: ৬২%', style: TextStyle(color: t.soft)),
        ])),
        const SizedBox(height: 20),
        SizedBox(height: 52, child: OutlinedButton(onPressed: () {}, child: Text(tr('pron')))),
        const SizedBox(height: 10),
        SizedBox(height: 52, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(t.btnR))),
          onPressed: () => go(const OverlayScreen()), child: Text(tr('now_q')))),
      ])),
    );
  }
}
