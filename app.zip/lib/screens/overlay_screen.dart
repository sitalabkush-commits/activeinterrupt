import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../core/i18n.dart';
import '../core/theme_tokens.dart';

// ওভারলে স্ক্রিন (নমুনা প্রশ্ন)। পরের ধাপে প্রশ্ন আসবে AI ও ডাটাবেস থেকে।
class OverlayScreen extends StatefulWidget {
  const OverlayScreen({super.key});
  @override
  State<OverlayScreen> createState() => _O();
}

class _O extends State<OverlayScreen> {
  final tts = FlutterTts();
  final ans = TextEditingController();
  static const question = '¿Cuál es la capital de Colombia?';
  static const opts = ['A) Bogotá', 'B) Lima', 'C) Quito', 'D) Caracas'];
  String? picked;
  int repeat = 5;

  @override
  void initState() { super.initState(); _speak(); }

  // ওভারলে খোলামাত্র স্প্যানিশে নির্দিষ্ট বার পড়া
  Future<void> _speak() async {
    await tts.setLanguage('es-MX');
    await tts.awaitSpeakCompletion(true);
    for (var i = 0; i < repeat; i++) { if (!mounted) return; await tts.speak(question); }
  }

  @override
  void dispose() { tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext c) {
    final t = tkOf(c);
    return Scaffold(
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('${tr('streak')} ১২', style: TextStyle(color: t.soft)),
          Text('XP 1,240', style: TextStyle(color: t.soft))]),
        const SizedBox(height: 12),
        Container(height: 200, alignment: Alignment.bottomLeft, padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(t.cardR),
            gradient: LinearGradient(colors: [t.imgA, t.imgB], begin: Alignment.topLeft, end: Alignment.bottomRight)),
          child: Text('Latin America', style: TextStyle(color: t.text))),
        const SizedBox(height: 16),
        const Text(question, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 48, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: t.accent2, foregroundColor: t.dark ? t.bg : Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(t.pillR))),
          onPressed: _speak, child: Text('${tr('listen')} ($repeat)'))),
        const SizedBox(height: 12),
        for (final o in opts) Padding(padding: const EdgeInsets.only(bottom: 8), child: SizedBox(
          width: double.infinity, height: 52, child: OutlinedButton(
            style: OutlinedButton.styleFrom(alignment: Alignment.centerLeft,
              side: BorderSide(color: picked == o ? t.accent2 : t.border, width: picked == o ? 2 : 1),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(t.btnR))),
            onPressed: () => setState(() => picked = o), child: Text(o)))),
        // উত্তরের বক্সে পেস্ট বন্ধ
        TextField(controller: ans, enableInteractiveSelection: false,
          contextMenuBuilder: (_, __) => const SizedBox.shrink(),
          decoration: InputDecoration(hintText: tr('type_es'))),
        const Spacer(),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          TextButton(onPressed: () {}, child: Text(tr('strict'))),
          TextButton(onPressed: () => Navigator.pop(c), child: Text(tr('exit'))),
        ]),
      ]))),
    );
  }
}
