import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// থিম-টোকেন: রং হুবহু নির্দেশ অনুযায়ী। বদলানো যাবে না।
class Tk {
  final Color bg, card, border, text, soft, accent, onAccent, accent2, imgA, imgB;
  final double cardR, btnR, pillR;
  final bool dark;
  const Tk(this.dark, this.bg, this.card, this.border, this.text, this.soft,
      this.accent, this.onAccent, this.accent2, this.imgA, this.imgB,
      this.cardR, this.btnR, this.pillR);

  static const indigo = Tk(true, Color(0xFF0F1220), Color(0xFF181C33),
      Color(0xFF2A3052), Color(0xFFE8EAF2), Color(0xFFA3A9C2), Color(0xFF8B93FF),
      Color(0xFF0F1220), Color(0xFF2DD4BF), Color(0xFF2A3052), Color(0xFF181C33),
      18, 13, 24);
  static const book = Tk(false, Color(0xFFF4F4F4), Color(0xFFFFFFFF),
      Color(0xFFCFCFCF), Color(0xFF1A1A1A), Color(0xFF5A5A5A), Color(0xFF1A1A1A),
      Color(0xFFFFFFFF), Color(0xFF6B6B6B), Color(0xFFD8D8D8), Color(0xFFB5B5B5),
      4, 4, 4);

  ThemeData theme() {
    final base = dark ? ThemeData.dark() : ThemeData.light();
    final tt = dark
        ? GoogleFonts.interTextTheme(base.textTheme)
        : GoogleFonts.loraTextTheme(base.textTheme);
    final bn = dark ? GoogleFonts.notoSansBengali().fontFamily! : GoogleFonts.notoSerifBengali().fontFamily!;
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      textTheme: tt.apply(bodyColor: text, displayColor: text, fontFamilyFallback: [bn]),
      colorScheme: base.colorScheme.copyWith(primary: accent, surface: card),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: card,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(btnR), borderSide: BorderSide(color: border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(btnR), borderSide: BorderSide(color: border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(btnR), borderSide: BorderSide(color: accent2)),
      ),
    );
  }
}

Tk tkOf(BuildContext c) => Theme.of(c).brightness == Brightness.dark ? Tk.indigo : Tk.book;
