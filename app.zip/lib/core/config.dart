// ডিফল্ট কনফিগ: মডেল তালিকা ব্যর্থ হলে এই ছোট তালিকা দেখানো হবে।
const Map<String, String> kProviderBase = {
  'groq': 'https://api.groq.com/openai/v1',
  'deepseek': 'https://api.deepseek.com/v1',
};
const Map<String, List<String>> kDefaultModels = {
  'groq': ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'],
  'deepseek': ['deepseek-chat'],
};
const int kDailyCallLimit = 200; // দৈনিক কল-সীমা
