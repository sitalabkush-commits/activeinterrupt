import 'package:flutter/foundation.dart';

// ত্রিভাষিক UI টেক্সট। ভাষা: bn / es / en
final ValueNotifier<String> appLang = ValueNotifier('bn');

const Map<String, Map<String, String>> _t = {
  'greet': {'bn': 'শুভ সকাল', 'es': 'Buenos días', 'en': 'Good morning'},
  'next_q': {'bn': 'পরের প্রশ্ন', 'es': 'Próxima pregunta', 'en': 'Next question'},
  'streak': {'bn': 'স্ট্রিক', 'es': 'Racha', 'en': 'Streak'},
  'level': {'bn': 'লেভেল', 'es': 'Nivel', 'en': 'Level'},
  'weak': {'bn': 'দুর্বলতা', 'es': 'Debilidades', 'en': 'Weakness'},
  'pron': {'bn': 'উচ্চারণ অনুশীলন', 'es': 'Práctica de pronunciación', 'en': 'Pronunciation practice'},
  'now_q': {'bn': 'এখনই প্রশ্ন দিন', 'es': 'Pregunta ahora', 'en': 'Ask now'},
  'ai_settings': {'bn': 'AI সেটিংস', 'es': 'Ajustes de IA', 'en': 'AI settings'},
  'ai_note': {'bn': 'key ডিভাইসে এনক্রিপ্ট করা থাকে, অ্যাপে কখনো দেখা যায় না', 'es': 'La clave se cifra en el dispositivo y nunca se muestra', 'en': 'The key is encrypted on the device and never shown'},
  'key_note': {'bn': 'সংরক্ষণের পর key আর দেখানো হয় না, শুধু বদলানো বা মোছা যায়', 'es': 'Tras guardar, la clave no se muestra; solo se cambia o se borra', 'en': 'After saving, the key is not shown; only change or delete'},
  'save': {'bn': 'সংরক্ষণ করুন', 'es': 'Guardar', 'en': 'Save'},
  'test': {'bn': 'টেস্ট', 'es': 'Probar', 'en': 'Test'},
  'del_key': {'bn': 'key মুছুন', 'es': 'Borrar clave', 'en': 'Delete key'},
  'model': {'bn': 'মডেলের নাম', 'es': 'Nombre del modelo', 'en': 'Model name'},
  'endpoint': {'bn': 'কাস্টম এন্ডপয়েন্ট (https)', 'es': 'Endpoint (https)', 'en': 'Custom endpoint (https)'},
  'listen': {'bn': 'আবার শুনুন', 'es': 'Escuchar otra vez', 'en': 'Listen again'},
  'strict': {'bn': 'কঠোর মোড', 'es': 'Modo estricto', 'en': 'Strict mode'},
  'exit': {'bn': 'জরুরি বেরোনোর পথ (PIN)', 'es': 'Salida de emergencia (PIN)', 'en': 'Emergency exit (PIN)'},
  'type_es': {'bn': 'স্প্যানিশে লিখুন', 'es': 'Escribe en español', 'en': 'Type in Spanish'},
};

String tr(String k) => _t[k]?[appLang.value] ?? k;
