import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// key ও AI সেটিংস নিরাপদ সংরক্ষণ (Android Keystore)। key কখনো লগে যাবে না।
class KeyStore {
  static const _s = FlutterSecureStorage();
  static Future<void> saveKey(String k) => _s.write(key: 'api_key', value: k.trim());
  static Future<String?> readKey() => _s.read(key: 'api_key'); // শুধু ভেতরের কলের জন্য
  static Future<void> deleteKey() => _s.delete(key: 'api_key');
  static Future<String> maskedTail() async {
    final k = await _s.read(key: 'api_key');
    if (k == null || k.length < 4) return '';
    return '••••${k.substring(k.length - 4)}';
  }
  static Future<void> setPref(String n, String v) => _s.write(key: 'pref_$n', value: v);
  static Future<String> getPref(String n, [String d = '']) async => (await _s.read(key: 'pref_$n')) ?? d;
}
