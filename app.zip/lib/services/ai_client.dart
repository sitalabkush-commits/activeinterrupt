import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config.dart';
import 'key_store.dart';

// OpenAI-সামঞ্জস্যপূর্ণ ক্লায়েন্ট। শুধু HTTPS।
class AiClient {
  static Future<String> _base() async {
    final p = await KeyStore.getPref('provider', 'groq');
    if (p == 'custom') {
      final e = (await KeyStore.getPref('endpoint')).trim();
      if (!e.startsWith('https://')) throw Exception('এন্ডপয়েন্ট অবশ্যই https হতে হবে');
      return e.replaceAll(RegExp(r'/+$'), '');
    }
    return kProviderBase[p == 'deepseek' ? 'deepseek' : 'groq']!;
  }

  static Future<String> chat(String prompt) async {
    final key = await KeyStore.readKey();
    if (key == null || key.isEmpty) throw Exception('key নেই');
    final model = await KeyStore.getPref('model', kDefaultModels['groq']!.first);
    final r = await http.post(
      Uri.parse('${await _base()}/chat/completions'),
      headers: {'Authorization': 'Bearer $key', 'Content-Type': 'application/json'},
      body: jsonEncode({'model': model, 'max_tokens': 300, 'messages': [{'role': 'user', 'content': prompt}]}),
    ).timeout(const Duration(seconds: 25));
    if (r.statusCode != 200) throw Exception('কোড ${r.statusCode}');
    return jsonDecode(utf8.decode(r.bodyBytes))['choices'][0]['message']['content'] as String;
  }

  // টেস্ট: ছোট কল। ফেরত: null = সফল, নইলে শান্ত বার্তা।
  static Future<String?> test() async {
    try { await chat('ok'); return null; } catch (e) {
      return 'key বা মডেল যাচাই করা যায়নি। আবার চেষ্টা করুন।';
    }
  }

  // মডেল তালিকা: ব্যর্থ হলে ডিফল্ট তালিকা
  static Future<List<String>> models() async {
    final p = await KeyStore.getPref('provider', 'groq');
    try {
      final key = await KeyStore.readKey();
      final r = await http.get(Uri.parse('${await _base()}/models'),
          headers: {'Authorization': 'Bearer $key'}).timeout(const Duration(seconds: 15));
      final l = (jsonDecode(r.body)['data'] as List).map((e) => e['id'].toString()).toList();
      if (l.isNotEmpty) return l;
    } catch (_) {}
    return kDefaultModels[p == 'deepseek' ? 'deepseek' : 'groq']!;
  }
}
